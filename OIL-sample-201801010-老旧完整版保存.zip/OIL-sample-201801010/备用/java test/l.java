public class l

{
      //程序的主函数入门

      public static void main(String args[])

      {
           //输出打印字符语句

          System.out.println("HelloWorld！");

      }

}

