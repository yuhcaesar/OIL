#ifndef __Log_H__   
#define __Log_H__  

 

#include <iostream>
#include<string.h>
#include<fstream> 
#include<time.h> 

using namespace std;

class Log
{
 public:
    


    void Init(string dirPath)
    {
        theDirName = dirPath;
	makeLogFileName();
        LogShow(1,"log is opened");
        Flush();
        cout<<"log is opened"<<endl;
    }
    void LogShow( int type, string theInformation)
    { 
      onAddLog();
      writeLog(type ,theInformation);
    }
    void Flush()
    {
        ofstream fout(theDirName+theFileName+theEndName,ios::app);
        fout<<theInformationSave; 
        theInformationSave = "";
    }
 private:

   string theDirName="./loger/";
   string theFileName = "Logs";
   string theEndName = ".log";
   const int theLogFileLength = 20000;
   int logCount=0;
   int theLogIndex =0;
    int today = 0;
    string timeString = "";
    string theInformationSave = "";
   void onAddLog()
   {
        logCount++;
         
        if(logCount >= theLogFileLength)
        {
         logCount=0;
         theLogIndex ++;
         Flush();
         makeLogFileName();
        }
   }

   void writeLog(string theInformation)
   {
       ofstream fout(theDirName+theFileName+theEndName,ios::app); 
       theInformationSave += timeString +" [info]: " +theInformation+"\n";
   }


   string  makeLogTitle(int type)
   {
       string  title = " [info]: ";
       switch (type)
      {
        case 1:
          title = " [info]: "; break;
	case 2:
		  title = " [warn]: "; break;
	case 3:
		  title = " [debug]: "; break;
	case 4:
		  title = " [erro]: "; break;
        default: 
		title = " [info]: "; break;
      }
       return  title;

   }
   void writeLog(int type ,string theInformation)
   {

       ofstream fout(theDirName+theFileName+theEndName,ios::app);
       theInformationSave += timeString + makeLogTitle(type) +theInformation+"\n";
   }
   void writeLogWithoutFlush(int type ,string theInformation)
   {
       ofstream fout(theDirName+theFileName+theEndName,ios::app);
       fout<<timeString +  makeLogTitle(type)+ theInformation<<endl;
   }
   void makeLogFileName()
   {
       time_t nowTime; 
       struct tm *timer;
       nowTime = time(NULL);
       timer = localtime(&nowTime);
       
       theFileName = "Log_"+ to_string((1900+timer->tm_year))+"_"+to_string((1+timer->tm_mon))+"_"+to_string(timer->tm_mday);
       theFileName += "_"+to_string(theLogIndex);

       timeString  = to_string(timer->tm_year+1900)+"-"+ to_string(timer->tm_mon+1)+"-"+to_string(timer->tm_mday)+" ";
       timeString  +=to_string(timer->tm_hour)+":"+ to_string(timer->tm_min) +":"+ to_string(timer->tm_sec) ;
   }

};

#endif
