#ifndef __logUse_H__   
#define __logUse_H__  

#include <iostream> 
#include<string.h>
#include "Log.h"
#include <pthread.h>

using namespace std;

class logController
{
  private:
   Log* GetLog()
   {  
       static  Log  theLogInstanceSingle  ;
       return &theLogInstanceSingle;
   }
  pthread_mutex_t* GetMutex()
  {
     static   pthread_mutex_t  Mutex;
       return &Mutex;
  } 
  public:
   void makeLog(int type,string theLogInformation)
   {
     pthread_mutex_lock(GetMutex());
     GetLog()->LogShow(type,theLogInformation);
     pthread_mutex_unlock(GetMutex());
   }
   void makeLogWithFlush(int type,string theLogInformation)
   {
     pthread_mutex_lock(GetMutex());
     GetLog()->LogShow(type,theLogInformation);
     GetLog()->Flush();
     pthread_mutex_unlock(GetMutex());
   }
   void InitTheLogModule(string dirPath)
   {
      GetLog()->Init(dirPath);
   }
   void Flush()
   {
       GetLog()->Flush();
   }
 
 
};

#endif




